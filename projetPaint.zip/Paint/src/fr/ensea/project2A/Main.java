package fr.ensea.project2A;

import java.awt.*;

public class Main {
    public static void main(String[] args) {
      //  System.out.println("Hello World");
        Rectangle test1 = new Rectangle(Color.black,1,2);
        System.out.println(test1);

    }

}
